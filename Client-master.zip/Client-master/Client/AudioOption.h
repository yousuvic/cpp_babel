#pragma once

typedef float				SAMPLE;
#define	SAMPLE_RATE			(24000)
#define	FRAMES_PER_BUFFER	(480)
#define	PA_SAMPLE_TYPE		paFloat32